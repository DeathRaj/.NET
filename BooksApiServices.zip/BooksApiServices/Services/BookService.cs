﻿using BooksApi.Models;

namespace BooksApi.Services
{
    //For CRUD on Books
    public class BookService
    {
        private List<Book>_books;

        public BookService() { 
            _books = new List<Book>();
        }

        //To Add Book

        public void AddBook(Book book)
        {
            _books.Add(book);
        }
        //To Get All Books
        public List<Book> GetAll()
        {
            return _books;
        }
        //To Get single Books
        public Book? GetBookyId(int id)
        {
            return _books.Find(x => x.Id == id);
        }
    }
}
